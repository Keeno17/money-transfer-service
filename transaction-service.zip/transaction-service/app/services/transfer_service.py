from decimal import Decimal
from sqlalchemy.orm import Session
import uuid
import hashlib

from app.models.transfer import Transfer
from app.models.ledger import LedgerEntry, EntryType
from app.repository.transfer_repo import TransferRepo
from app.repository.account_repo import AccountRepo
from app.repository.ledger_repo import LedgerRepo


#SHA-256

class TransferService:

    @staticmethod
    def get_transfer_by_id(session: Session, transfer_id: uuid.UUID) -> Transfer | None:
        if not transfer_id:
            raise ValueError("Transfer ID must be provided")
        return TransferRepo.get_by_id(session, transfer_id)

    @staticmethod
    def get_all_transfers(session: Session) -> list[Transfer]:
        return TransferRepo.get_all(session)

    @staticmethod
    def create_transfer(
        session: Session,
        from_account: uuid.UUID,
        to_account: uuid.UUID,
        amount: Decimal,
        idempotency_key: str,
    ) -> Transfer:

        if not from_account or not to_account:
            raise ValueError("Both source and destination account must be provided")

        if not amount or amount <= 0:
            raise ValueError("Amount must be greater than 0")

        if not idempotency_key:
            raise ValueError("Idempotency key must be provided")

        existing_transfer = TransferRepo.get_by_idempotency_key(
            session, idempotency_key
        )

        request_fingerprint = hashlib.sha256(from_account.bytes + to_account.bytes + str(amount).encode()).hexdigest()

        if existing_transfer:
            if (
                request_fingerprint != existing_transfer.request_hash
            ):
                raise ValueError(
                    "A transfer with the same idempotency key already exists with different details"
                )
            return existing_transfer

        src_account = AccountRepo.get_by_id(session, from_account)
        dest_account = AccountRepo.get_by_id(session, to_account)

        if not src_account or not dest_account:
            raise ValueError("Both the source and destination account must exist")

        if from_account == to_account:
            raise ValueError("Source and destination account cannot be the same")

        if src_account.balance < amount:
            raise ValueError("Insufficient funds in the source account")

        new_transfer = Transfer(
            from_account=from_account,
            to_account=to_account,
            amount=amount,
            idempotency_key=idempotency_key,
            request_hash=request_fingerprint,
        )

        new_transfer = TransferRepo.create(session, new_transfer)

        session.commit()

        return new_transfer

        
    @staticmethod
    def create_ledger_entry(
        session: Session,
        transfer_id: uuid.UUID,
        account_id: uuid.UUID,
    ) -> LedgerEntry:
        
        if not transfer_id:
            raise ValueError("Transfer ID must be provided")
        if not account_id:
            raise ValueError("Account ID must be provided")

        transfer = TransferRepo.get_by_id(session, transfer_id)

        if transfer.from_account == account_id:
            entry_type = EntryType.DEBIT
            amount = -transfer.amount

        if transfer.to_account == account_id:
            entry_type = EntryType.CREDIT
            amount = transfer.amount

        new_ledger_entry = LedgerEntry(
            account_id=account_id,
            amount=amount,
            entry_type=entry_type,
            transfer_id=transfer_id,
        )

        new_ledger_entry = LedgerRepo.create(session, new_ledger_entry)

        Session.commit()

        return new_ledger_entry

    @staticmethod
    def updateBalance(session: Session, account_id: uuid.UUID, amount: Decimal) -> None:
        account = AccountRepo.get_by_id(session, account_id)
        if not account:
            raise ValueError("Account not found")
        account.balance += amount
        AccountRepo.update(session, account)